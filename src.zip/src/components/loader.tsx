import React from "react";

export function Loader() {
    return (
        <p className='text-center '>Loading...</p>
    )
}