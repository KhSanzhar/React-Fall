import React from "react";

export function AboutPage() {
    return (
        <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis, fuga quos? Repellat similique cupiditate optio. Dicta quia illum ducimus nemo sed dolore consequuntur eligendi hic ab magnam sequi atque doloremque omnis earum repellendus culpa, iusto voluptatem officiis, mollitia repellat labore sit. Architecto corrupti laboriosam cupiditate autem provident maiores incidunt impedit!</div>
    )
}